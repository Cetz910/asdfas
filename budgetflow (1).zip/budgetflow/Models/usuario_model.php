<?php
class UsuarioModel {
    // Verificar credenciales de inicio de sesión
    public static function login($email, $password) {
        try {
            $db = Conexion::conectar();
            $stmt = $db->prepare("SELECT * FROM usuarios WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
                if (password_verify($password, $usuario['password'])) {
                    if ($usuario['verificado'] == 1) {
                        return ['status' => 'success', 'data' => $usuario];
                    } else {
                        return ['status' => 'error', 'message' => 'Cuenta no verificada'];
                    }
                }
            }
            return ['status' => 'error', 'message' => 'Credenciales incorrectas'];
        } catch(PDOException $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    // Registrar nuevo usuario
    public static function registrar($nombre, $email, $password, $edad) {
        try {
            $db = Conexion::conectar();
            
            // Verificar si el correo ya existe
            $stmt = $db->prepare("SELECT * FROM usuarios WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                return ['status' => 'error', 'message' => 'El correo ya está registrado'];
            }
            
            // Crear código de verificación
            $codigo = sprintf("%06d", mt_rand(1, 999999));
            $codigo_expira = date('Y-m-d H:i:s', strtotime('+30 minutes'));
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $stmt = $db->prepare("INSERT INTO usuarios (nombre, email, password, edad, codigo_verificacion, codigo_expira) VALUES (:nombre, :email, :password, :edad, :codigo, :codigo_expira)");
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $hashed_password);
            $stmt->bindParam(':edad', $edad);
            $stmt->bindParam(':codigo', $codigo);
            $stmt->bindParam(':codigo_expira', $codigo_expira);
            $stmt->execute();
            
            return [
                'status' => 'success', 
                'message' => 'Usuario registrado',
                'codigo' => $codigo,
                'email' => $email
            ];
        } catch(PDOException $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    // Verificar código de activación
    public static function verificarCodigo($email, $codigo) {
        try {
            $db = Conexion::conectar();
            $stmt = $db->prepare("SELECT * FROM usuarios WHERE email = :email AND codigo_verificacion = :codigo AND codigo_expira > NOW()");
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':codigo', $codigo);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                $stmt = $db->prepare("UPDATE usuarios SET verificado = 1, codigo_verificacion = NULL, codigo_expira = NULL WHERE email = :email");
                $stmt->bindParam(':email', $email);
                $stmt->execute();
                
                return ['status' => 'success', 'message' => 'Cuenta verificada'];
            }
            
            return ['status' => 'error', 'message' => 'Código inválido o expirado'];
        } catch(PDOException $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    // Generar solicitud de recuperación de contraseña
    public static function recuperarPassword($email) {
        try {
            $db = Conexion::conectar();
            $stmt = $db->prepare("SELECT * FROM usuarios WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                $token = bin2hex(random_bytes(50));
                $token_expira = date('Y-m-d H:i:s', strtotime('+1 hour'));
                
                $stmt = $db->prepare("UPDATE usuarios SET token_recuperacion = :token, token_expira = :token_expira WHERE email = :email");
                $stmt->bindParam(':token', $token);
                $stmt->bindParam(':token_expira', $token_expira);
                $stmt->bindParam(':email', $email);
                $stmt->execute();
                
                return ['status' => 'success', 'message' => 'Solicitud enviada', 'token' => $token, 'email' => $email];
            }
            
            return ['status' => 'error', 'message' => 'Email no encontrado'];
        } catch(PDOException $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    // Cambiar contraseña
    public static function cambiarPassword($email, $token, $password) {
        try {
            $db = Conexion::conectar();
            $stmt = $db->prepare("SELECT * FROM usuarios WHERE email = :email AND token_recuperacion = :token AND token_expira > NOW()");
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':token', $token);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt = $db->prepare("UPDATE usuarios SET password = :password, token_recuperacion = NULL, token_expira = NULL WHERE email = :email");
                $stmt->bindParam(':password', $hashed_password);
                $stmt->bindParam(':email', $email);
                $stmt->execute();
                
                return ['status' => 'success', 'message' => 'Contraseña actualizada'];
            }
            
            return ['status' => 'error', 'message' => 'Token inválido o expirado'];
        } catch(PDOException $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
}
?>