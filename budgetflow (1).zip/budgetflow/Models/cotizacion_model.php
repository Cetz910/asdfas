<?php
class CotizacionModel {
    // Registrar una nueva cotización
    public static function registrarCotizacion($id_usuario, $id_empresa, $material, $dimensiones, $cantidad, $fecha_solicitud) {
        try {
            $db = Conexion::conectar();
            
            $stmt = $db->prepare("INSERT INTO cotizaciones (id_usuario, id_empresa, material, dimensiones, cantidad, fecha_solicitud) VALUES (:id_usuario, :id_empresa, :material, :dimensiones, :cantidad, :fecha_solicitud)");
            $stmt->bindParam(':id_usuario', $id_usuario);
            $stmt->bindParam(':id_empresa', $id_empresa);
            $stmt->bindParam(':material', $material);
            $stmt->bindParam(':dimensiones', $dimensiones);
            $stmt->bindParam(':cantidad', $cantidad);
            $stmt->bindParam(':fecha_solicitud', $fecha_solicitud);
            $stmt->execute();
            
            return ['status' => 'success', 'message' => 'Cotización registrada con éxito'];
        } catch(PDOException $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    // Obtener las cotizaciones de un usuario
    public static function obtenerCotizacionesPorUsuario($id_usuario) {
        try {
            $db = Conexion::conectar();
            
            $stmt = $db->prepare("SELECT * FROM cotizaciones WHERE id_usuario = :id_usuario ORDER BY fecha_registro DESC");
            $stmt->bindParam(':id_usuario', $id_usuario);
            $stmt->execute();
            
            return ['status' => 'success', 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)];
        } catch(PDOException $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    // Eliminar una cotización
    public static function eliminarCotizacion($id_cotizacion, $id_usuario) {
        try {
            $db = Conexion::conectar();
            
            // Verificar que la cotización pertenezca al usuario
            $stmt = $db->prepare("SELECT id FROM cotizaciones WHERE id = :id_cotizacion AND id_usuario = :id_usuario");
            $stmt->bindParam(':id_cotizacion', $id_cotizacion);
            $stmt->bindParam(':id_usuario', $id_usuario);
            $stmt->execute();
            
            if ($stmt->rowCount() === 0) {
                return ['status' => 'error', 'message' => 'No tienes permiso para eliminar esta cotización'];
            }
            
            $stmt = $db->prepare("DELETE FROM cotizaciones WHERE id = :id_cotizacion");
            $stmt->bindParam(':id_cotizacion', $id_cotizacion);
            $stmt->execute();
            
            return ['status' => 'success', 'message' => 'Cotización eliminada con éxito'];
        } catch(PDOException $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    // Registrar un reporte
    public static function registrarReporte($id_usuario, $tipo_problema, $descripcion, $email_contacto) {
        try {
            $db = Conexion::conectar();
            
            $stmt = $db->prepare("INSERT INTO reportes (id_usuario, tipo_problema, descripcion, email_contacto) VALUES (:id_usuario, :tipo_problema, :descripcion, :email_contacto)");
            $stmt->bindParam(':id_usuario', $id_usuario);
            $stmt->bindParam(':tipo_problema', $tipo_problema);
            $stmt->bindParam(':descripcion', $descripcion);
            $stmt->bindParam(':email_contacto', $email_contacto);
            $stmt->execute();
            
            return ['status' => 'success', 'message' => 'Reporte enviado con éxito'];
        } catch(PDOException $e) {
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
}
?>