<?php
class ClienteController {
    // Mostrar el dashboard del cliente
    public function dashboard() {
        include "Views/cliente/dashboard.php";
    }
    
    // Mostrar el formulario de solicitud de cotización
    public function solicitarCotizacion() {
        include "Views/cliente/solicitar_cotizacion.php";
    }
    
    // Procesar la solicitud de cotización
    public function procesarCotizacion() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_empresa = $_POST['id_empresa'] ?? '';
            $material = $_POST['material'] ?? '';
            $dimensiones = $_POST['dimensiones'] ?? '';
            $cantidad = $_POST['cantidad'] ?? '';
            $fecha = $_POST['fecha'] ?? '';
            
            if (empty($id_empresa) || empty($material) || empty($dimensiones) || empty($cantidad) || empty($fecha)) {
                $_SESSION['error'] = 'Todos los campos son obligatorios';
                header('Location: index.php?action=cliente_solicitar_cotizacion');
                exit;
            }
            
            // Registrar la cotización en la base de datos
            $resultado = CotizacionModel::registrarCotizacion(
                $_SESSION['usuario_id'],
                $id_empresa,
                $material,
                $dimensiones,
                $cantidad,
                $fecha
            );
            
            if ($resultado['status'] === 'success') {
                // Redirigir a la página de éxito
                header('Location: index.php?action=cliente_cotizacion_exito');
            } else {
                $_SESSION['error'] = $resultado['message'];
                header('Location: index.php?action=cliente_solicitar_cotizacion');
            }
            exit;
        }
    }
    
    // Mostrar el historial de cotizaciones
    public function historialCotizaciones() {
        // Obtener las cotizaciones del usuario actual
        $resultado = CotizacionModel::obtenerCotizacionesPorUsuario($_SESSION['usuario_id']);
        
        if ($resultado['status'] === 'success') {
            $cotizaciones = $resultado['data'];
        } else {
            $cotizaciones = [];
            $_SESSION['error'] = $resultado['message'];
        }
        
        // Incluir la vista con los datos
        include "Views/cliente/historial_cotizaciones.php";
    }
    
    // Eliminar una cotización
    public function eliminarCotizacion() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_cotizacion'])) {
            $id_cotizacion = $_POST['id_cotizacion'];
            
            $resultado = CotizacionModel::eliminarCotizacion($id_cotizacion, $_SESSION['usuario_id']);
            
            if ($resultado['status'] === 'success') {
                $_SESSION['global_success'] = $resultado['message'];
            } else {
                $_SESSION['global_error'] = $resultado['message'];
            }
            
            header('Location: index.php?action=cliente_historial_cotizaciones');
            exit;
        }
    }
    
    // Mostrar la página de éxito de cotización
    public function cotizacionExito() {
        include "Views/cliente/cotizacion_exito.php";
    }
    
    // Generar un reporte
    public function generarReporte() {
        include "Views/cliente/generar_reporte.php";
    }
    
    // Enviar un reporte
    public function enviarReporte() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $tipo_problema = $_POST['tipo_problema'] ?? '';
            $descripcion = $_POST['descripcion'] ?? '';
            $email_contacto = $_POST['email_contacto'] ?? '';
            
            if (empty($tipo_problema) || empty($descripcion) || empty($email_contacto)) {
                $_SESSION['error'] = 'Todos los campos son obligatorios';
                header('Location: index.php?action=cliente_generar_reporte');
                exit;
            }
            
            // Registrar el reporte en la base de datos
            $resultado = CotizacionModel::registrarReporte(
                $_SESSION['usuario_id'],
                $tipo_problema,
                $descripcion,
                $email_contacto
            );
            
            if ($resultado['status'] === 'success') {
                $_SESSION['global_success'] = 'Reporte enviado con éxito. Nos pondremos en contacto contigo pronto.';
                header('Location: index.php?action=dashboard_cliente');
            } else {
                $_SESSION['error'] = $resultado['message'];
                header('Location: index.php?action=cliente_generar_reporte');
            }
            exit;
        }
    }
}
?>