<?php
class MainController {
    private $authController;
    private $clienteController;
    
    public function __construct() {
        $this->authController = new AuthController();
        $this->clienteController = new ClienteController();
    }
    
    public function route() {
        // Definir la acción predeterminada
        $action = isset($_GET['action']) ? $_GET['action'] : 'login';
        
        // Procesar acciones de formularios
        if ($action === 'procesar_login') {
            $this->authController->procesarLogin();
            return;
        } elseif ($action === 'procesar_registro') {
            $this->authController->procesarRegistro();
            return;
        } elseif ($action === 'procesar_recuperar') {
            $this->authController->procesarRecuperar();
            return;
        } elseif ($action === 'procesar_verificacion') {
            $this->authController->procesarVerificacion();
            return;
        } elseif ($action === 'procesar_restablecer') {
            $this->authController->procesarRestablecer();
            return;
        } elseif ($action === 'verificar_codigo_recuperacion') {
            $this->authController->verificarCodigoRecuperacion();
            return;
        } elseif ($action === 'cerrar_sesion') {
            $this->authController->cerrarSesion();
            return;
        } elseif ($action === 'cliente_procesar_cotizacion') {
            $this->clienteController->procesarCotizacion();
            return;
        } elseif ($action === 'cliente_enviar_reporte') {
            $this->clienteController->enviarReporte();
            return;
        }
        
        // Verificar si es una ruta protegida
        if ($this->requiereSesion($action)) {
            if (!isset($_SESSION['usuario_id'])) {
                $_SESSION['error'] = 'Debes iniciar sesión para acceder';
                header('Location: index.php?action=login');
                exit;
            }
            
            // Verificar permisos según el rol
            if (strpos($action, 'admin_') === 0 && $_SESSION['usuario_role'] !== 'admin') {
                header('Location: index.php?action=dashboard_cliente');
                exit;
            } else if (strpos($action, 'cliente_') === 0 && $_SESSION['usuario_role'] !== 'cliente') {
                header('Location: index.php?action=dashboard_admin');
                exit;
            }
        }
        
        // Incluir la plantilla principal
        include "Views/template.php";
        
        // Cargar la vista correspondiente
        if ($action === 'login') {
            include "Views/auth/login.php";
        } elseif ($action === 'registro') {
            include "Views/auth/registro.php";
        } elseif ($action === 'recuperar') {
            include "Views/auth/recuperar.php";
        } elseif ($action === 'verificacion') {
            include "Views/auth/verificacion.php";
        } elseif ($action === 'codigo_recuperacion') {
            include "Views/auth/codigo_recuperacion.php";
        } elseif ($action === 'restablecer') {
            include "Views/auth/restablecer.php";
        } elseif ($action === 'dashboard_admin') {
            include "Views/admin/dashboard.php";
        } elseif ($action === 'dashboard_cliente') {
            $this->clienteController->dashboard();
        } elseif ($action === 'cliente_solicitar_cotizacion') {
            $this->clienteController->solicitarCotizacion();
        } elseif ($action === 'cliente_historial_cotizaciones') {
            $this->clienteController->historialCotizaciones();
        } elseif ($action === 'cliente_cotizacion_exito') {
            $this->clienteController->cotizacionExito();
        } elseif ($action === 'cliente_generar_reporte') {
            $this->clienteController->generarReporte();
        } else {
            // Vista por defecto
            include "Views/auth/login.php";
        }
    }
    
    private function requiereSesion($action) {
        $rutasProtegidas = [
            'dashboard_admin',
            'dashboard_cliente',
            'admin_usuarios',
            'admin_estadisticas',
            'admin_configuracion',
            'cliente_solicitar_cotizacion',
            'cliente_historial_cotizaciones',
            'cliente_cotizacion_exito',
            'cliente_generar_reporte',
            // Añade aquí todas tus rutas protegidas
        ];
        
        return in_array($action, $rutasProtegidas);
    }
}
?>