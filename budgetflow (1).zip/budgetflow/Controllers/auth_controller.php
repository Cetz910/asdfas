<?php
class AuthController {
    // Procesar inicio de sesión
    public function procesarLogin() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            
            if (empty($email) || empty($password)) {
                $_SESSION['error'] = 'Todos los campos son obligatorios';
                header('Location: index.php?action=login');
                exit;
            }
            
            $resultado = UsuarioModel::login($email, $password);
            
            if ($resultado['status'] === 'success') {
                $_SESSION['usuario_id'] = $resultado['data']['id'];
                $_SESSION['usuario_nombre'] = $resultado['data']['nombre'];
                $_SESSION['usuario_role'] = $resultado['data']['role'];
                
                if ($resultado['data']['role'] === 'admin') {
                    header('Location: index.php?action=dashboard_admin');
                } else {
                    header('Location: index.php?action=dashboard_cliente');
                }
                exit;
            } else {
                $_SESSION['error'] = $resultado['message'];
                header('Location: index.php?action=login');
                exit;
            }
        }
    }
    
    // Procesar registro
    public function procesarRegistro() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = $_POST['nombre'] ?? '';
            $email = $_POST['email'] ?? '';
            $edad = $_POST['edad'] ?? '';
            $password = $_POST['password'] ?? '';
            $confirmar_password = $_POST['confirmar_password'] ?? '';
            
            if (empty($nombre) || empty($email) || empty($edad) || empty($password) || empty($confirmar_password)) {
                $_SESSION['error'] = 'Todos los campos son obligatorios';
                header('Location: index.php?action=registro');
                exit;
            }
            
            if ($password !== $confirmar_password) {
                $_SESSION['error'] = 'Las contraseñas no coinciden';
                header('Location: index.php?action=registro');
                exit;
            }
            
            $resultado = UsuarioModel::registrar($nombre, $email, $password, $edad);
            
            if ($resultado['status'] === 'success') {
                // Aquí normalmente enviarías un correo con el código
                // Para fines de demostración, guardamos el código en sesión
                $_SESSION['verificacion_email'] = $resultado['email'];
                $_SESSION['verificacion_codigo'] = $resultado['codigo'];
                
                header('Location: index.php?action=verificacion');
                exit;
            } else {
                $_SESSION['error'] = $resultado['message'];
                header('Location: index.php?action=registro');
                exit;
            }
        }
    }
    
    // Procesar verificación
    public function procesarVerificacion() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $codigo = $_POST['codigo'] ?? '';
            $email = $_SESSION['verificacion_email'] ?? '';
            
            if (empty($codigo) || empty($email)) {
                $_SESSION['error'] = 'Código inválido';
                header('Location: index.php?action=verificacion');
                exit;
            }
            
            $resultado = UsuarioModel::verificarCodigo($email, $codigo);
            
            if ($resultado['status'] === 'success') {
                unset($_SESSION['verificacion_email']);
                unset($_SESSION['verificacion_codigo']);
                
                $_SESSION['global_success'] = 'Cuenta verificada con éxito. Ya puedes iniciar sesión.';
                header('Location: index.php?action=login');
                exit;
            } else {
                $_SESSION['error'] = $resultado['message'];
                header('Location: index.php?action=verificacion');
                exit;
            }
        }
    }
    
    // Procesar recuperación de contraseña
    public function procesarRecuperar() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            
            if (empty($email)) {
                $_SESSION['error'] = 'El correo es obligatorio';
                header('Location: index.php?action=recuperar');
                exit;
            }
            
            $resultado = UsuarioModel::recuperarPassword($email);
            
            if ($resultado['status'] === 'success') {
                // Aquí normalmente enviarías un correo con el enlace
                // Para fines de demostración, guardamos el token en sesión
                $_SESSION['reset_email'] = $resultado['email'];
                $_SESSION['reset_token'] = $resultado['token'];
                
                // Redirigir a la nueva página de código
                header('Location: index.php?action=codigo_recuperacion');
                exit;
            } else {
                $_SESSION['error'] = $resultado['message'];
                header('Location: index.php?action=recuperar');
                exit;
            }
        }
    }
    
    // Verificar código de recuperación
    public function verificarCodigoRecuperacion() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $codigo = $_POST['codigo'] ?? '';
            $email = $_SESSION['reset_email'] ?? '';
            $token = $_SESSION['reset_token'] ?? '';
            
            if (empty($codigo) || empty($email) || empty($token)) {
                $_SESSION['error'] = 'Código inválido';
                header('Location: index.php?action=codigo_recuperacion');
                exit;
            }
            
            // Verificar si el código coincide con los primeros 6 caracteres del token
            if (substr($token, 0, 6) === $codigo) {
                // Código válido, redirigir a la página de restablecer contraseña
                header("Location: index.php?action=restablecer");
                exit;
            } else {
                $_SESSION['error'] = 'Código incorrecto';
                header('Location: index.php?action=codigo_recuperacion');
                exit;
            }
        }
    }
    
    // Procesar cambio de contraseña
    public function procesarRestablecer() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $password = $_POST['password'] ?? '';
            $confirmar_password = $_POST['confirmar_password'] ?? '';
            $email = $_SESSION['reset_email'] ?? '';
            $token = $_SESSION['reset_token'] ?? '';
            
            if (empty($password) || empty($confirmar_password) || empty($email) || empty($token)) {
                $_SESSION['error'] = 'Todos los campos son obligatorios';
                header("Location: index.php?action=restablecer");
                exit;
            }
            
            if ($password !== $confirmar_password) {
                $_SESSION['error'] = 'Las contraseñas no coinciden';
                header("Location: index.php?action=restablecer");
                exit;
            }
            
            $resultado = UsuarioModel::cambiarPassword($email, $token, $password);
            
            if ($resultado['status'] === 'success') {
                unset($_SESSION['reset_email']);
                unset($_SESSION['reset_token']);
                
                $_SESSION['global_success'] = 'Contraseña actualizada con éxito';
                header('Location: index.php?action=login');
                exit;
            } else {
                $_SESSION['error'] = $resultado['message'];
                header("Location: index.php?action=restablecer");
                exit;
            }
        }
    }
    
    // Cerrar sesión
    public function cerrarSesion() {
        session_unset();
        session_destroy();
        header('Location: index.php?action=login');
        exit;
    }
}
?>