<div class="header">
    <div class="logo">
        <div class="logo-icon"></div>
        <h1>BudgetFlow</h1>
    </div>
</div>

<h2 class="section-title">¿Olvidaste tu contraseña?</h2>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<div class="form-container">
    <form action="index.php?action=procesar_recuperar" method="POST">
        <div class="form-group">
            <label for="email">Ingresa tu correo electrónico:</label>
            <input type="email" id="email" name="email" required>
        </div>
        
        <div class="form-group text-center">
            <button type="submit" class="btn-primary">Enviar código de recuperación</button>
        </div>
    </form>
</div>

<div class="links-container text-center">
    <a href="index.php?action=login">Volver a iniciar sesión</a>
</div>