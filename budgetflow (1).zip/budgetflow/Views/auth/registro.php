<div class="header">
    <div class="logo">
        <div class="logo-icon"></div>
        <h1>BudgetFlow</h1>
    </div>
</div>

<h2 class="section-title">Registro</h2>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<div class="form-container">
    <form action="index.php?action=procesar_registro" method="POST">
        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" id="nombre" name="nombre" required>
        </div>
        
        <div class="form-group">
            <label for="edad">Edad</label>
            <input type="number" id="edad" name="edad" min="18" max="120" required>
        </div>
        
        <div class="form-group">
            <label for="email">Correo</label>
            <input type="email" id="email" name="email" required>
        </div>
        
        <div class="form-group">
            <label for="password">Contraseña</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <div class="form-group">
            <label for="confirmar_password">Confirmar Contraseña</label>
            <input type="password" id="confirmar_password" name="confirmar_password" required>
        </div>
        
        <div class="form-group text-center">
            <button type="submit" class="btn-primary">Registrarse</button>
        </div>
    </form>
</div>

<div class="links-container text-center">
    <a href="index.php?action=login">¿Ya tienes cuenta? Iniciar sesión</a>
</div>