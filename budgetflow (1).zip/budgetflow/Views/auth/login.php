<div class="header">
    <div class="logo">
        <div class="logo-icon"></div>
        <h1>BudgetFlow</h1>
    </div>
</div>

<h2 class="section-title">Login</h2>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<div class="form-container">
    <form action="index.php?action=procesar_login" method="POST">
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
        </div>
        
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <div class="form-group text-center">
            <button type="submit" class="btn-primary">Sign In</button>
        </div>
    </form>
</div>

<div class="links-container">
    <a href="index.php?action=registro">Registrarse</a>
    <a href="index.php?action=recuperar">¿Olvidaste tu contraseña?</a>
</div>

<div class="social-container">
    <p>O iniciar sesión con:</p>
    <div class="social-buttons">
        <a href="#" class="social-btn facebook">
            <svg width="20" height="20" viewBox="0 0 320 512" fill="#ffffff">
                <path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"/>
            </svg>
        </a>
        
        <a href="#" class="social-btn google">
            <svg width="20" height="20" viewBox="0 0 488 512" fill="#ffffff">
                <path d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h236.1c2.3 12.7 3.9 24.9 3.9 41.4z"/>
            </svg>
        </a>
        
        <a href="#" class="social-btn outlook">
            <svg width="20" height="20" viewBox="0 0 512 512" fill="#ffffff">
                <path d="M256 153.9l-160 73.6v-96.3l160-65.7zM88 352V208l160 72-160 72zm192-184v128l160-64V112zm80 184h-80v-64l80-36z"/>
            </svg>
        </a>
    </div>
</div>