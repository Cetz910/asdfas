<div class="header">
    <div class="logo">
        <div class="logo-icon"></div>
        <h1>BudgetFlow</h1>
    </div>
</div>

<h2 class="section-title">Verificación de cuenta</h2>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<div class="verification-message">
    <p>Hemos enviado un código de verificación al correo: 
        <strong><?php echo isset($_SESSION['verificacion_email']) ? $_SESSION['verificacion_email'] : ''; ?></strong>
    </p>
    <p>Ingresa el código para verificar tu cuenta.</p>
    
    <?php if (isset($_SESSION['verificacion_codigo'])): ?>
        <div class="alert alert-info">
            Para fines de demostración, el código es: <?php echo $_SESSION['verificacion_codigo']; ?>
        </div>
    <?php endif; ?>
</div>

<div class="form-container">
    <form action="index.php?action=procesar_verificacion" method="POST">
        <div class="form-group">
            <input type="text" name="codigo" placeholder="Ingresa el código" maxlength="6" class="verification-input" required>
        </div>
        
        <div class="form-group text-center">
            <button type="submit" class="btn-primary">Verificar código</button>
        </div>
    </form>
</div>

<div class="verification-resend">
    <p>¿No recibiste el código? <a href="#">Reenviar código</a></p>
</div>