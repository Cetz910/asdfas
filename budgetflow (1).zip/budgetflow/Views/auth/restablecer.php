<div class="header">
    <div class="logo">
        <div class="logo-icon"></div>
        <h1>BudgetFlow</h1>
    </div>
</div>

<h2 class="section-title">Restablecer Contraseña</h2>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<div class="form-container">
    <form action="index.php?action=procesar_restablecer" method="POST">
        <div class="form-group">
            <label for="password">Escribe tu nueva contraseña</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <div class="form-group">
            <label for="confirmar_password">Confirme su contraseña</label>
            <input type="password" id="confirmar_password" name="confirmar_password" required>
        </div>
        
        <div class="form-group text-center">
            <button type="submit" class="btn-primary">Restablecer contraseña</button>
        </div>
    </form>
</div>