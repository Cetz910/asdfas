<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Bienvenido Admin</title>
    <style>
    body {
    margin: 0;
    padding: 0;
    background-color: #0f0f0f;
    font-family: 'Segoe UI', sans-serif;
    color: white;
}

.container {
    max-width: 1000px;
    margin: 0 auto;
    padding: 40px 20px;
    text-align: center;
}

.back {
    color: white;
    text-decoration: none;
    font-size: 18px;
    display: inline-block;
    margin-bottom: 20px;
    transition: color 0.3s;
}

.back:hover {
    color: #888;
}

h1 {
    font-size: 28px;
    margin-bottom: 40px;
}

.botonera {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 25px;
}

.boton {
    background-color: #1a1a1a;
    color: white;
    border: 1px solid #333;
    border-radius: 16px;
    width: 310px;
    height: 210px;
    font-size: 14px;
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    transition: background-color 0.3s, transform 0.2s;
    padding: 10px;
    text-decoration: none; /* 👈 Esto es lo que quita el subrayado */
}


.boton i {
    font-size: 28px;
    color: #7b61ff;
    margin-bottom: 12px;
}

.boton span {
    display: block;
    color: white;
    font-size: 14px;
    line-height: 1.2;
    padding: 0 8px;
}

.boton:hover {
    background-color: #2a2a2a;
    transform: scale(1.05);
}
</style>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <a href="#" class="back"><i class="fas fa-arrow-left"></i></a>
        <h1>Bienvenido Admin</h1>
        <div class="botonera">
            <a href="a.php" class="boton"><i class="fas fa-search"></i><span>Búsqueda</span></a>
            <a href="agregar_historial.php" class="boton"><i class="fas fa-pen"></i><span>Agregar, verificar y ver historial</span></a>
            <a href="historial.php" class="boton"><i class="fas fa-clock"></i><span>Historial de cotizaciones</span></a>
            <a href="proveedores.php" class="boton"><i class="fas fa-truck"></i><span>Gestionar Proveedores</span></a>
            <a href="parametros.php" class="boton"><i class="fas fa-sliders-h"></i><span>Configurar parámetros</span></a>
        </div>
    </div>
</body>
</html>
