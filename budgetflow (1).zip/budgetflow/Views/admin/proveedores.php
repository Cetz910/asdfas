<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestionar Proveedores</title>
    <style>body {
    margin: 0;
    padding: 0;
    background-color: #0f0f0f;
    font-family: 'Segoe UI', sans-serif;
    color: white;
}

.container {
    max-width: 1500px;
    max-height: 2000px;
    margin: 60px auto;
    padding: 30px 40px;
    background-color: #0f0f0f;
}

.back {
    color: white;
    text-decoration: none;
    font-size: 16px;
    display: inline-block;
    margin-bottom: 20px;
}

h1 {
    font-size: 26px;
    margin-bottom: 30px;
    text-align: center;
}

.botonera {
    display: flex;
    justify-content: center;
    gap: 25px;
    margin-bottom: 40px;
}

.boton {
    background-color: #1f1f1f;
    border: 1px solid #333;
    border-radius: 16px;
    width: 160px;
    height: 100px;
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    color: white;
    text-decoration: none;
    transition: 0.3s;
}

.boton:hover {
    background-color: #1a1a1a;
    transform: scale(1.05);
}

.boton i {
    font-size: 30px;
    color: #7b61ff;
    margin-bottom: 10px;
}

.boton span {
    font-size: 14px;
}

table {
    width: 100%;
    border-collapse: collapse;
    background-color: #1f1f1f;
    border-radius: 12px;
    overflow: hidden;
}

th, td {
    padding: 14px 12px;
    text-align: left;
    border-bottom: 1px solid #333;
}

th {
    background-color: #1f1f1f;
    font-weight: 600;
}

td i {
    font-size: 16px;
    margin-right: 8px;
    cursor: pointer;
}

.text-yellow { color: #facc15; }
.text-red { color: #ef4444; }

.reporte {
    text-align: right;
    margin-top: 15px;
    font-size: 14px;
    color: #ccc;
}

.reporte a {
    color: #7b61ff;
    text-decoration: none;
}

.reporte a:hover {
    text-decoration: underline;
}</style>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="container box">
        <a href="dashboard.php" class="back"><i class="fas fa-arrow-left"></i></a>
        <h1>Gestionar proveedores</h1>

        <div class="botonera">
            <a href="#" class="boton"><i class="fas fa-plus"></i><span>Agregar Proveedores</span></a>
            <a href="#" class="boton"><i class="fas fa-pen"></i><span>Editar Proveedores</span></a>
        </div>

        <h2>Lista de proveedores</h2>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Material</th>
                    <th>Costo unitario</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Proveedor A</td>
                    <td>Acero</td>
                    <td>$150.00 MXN</td>
                    <td>
                        <i class="fas fa-pen text-yellow"></i>
                        <i class="fas fa-times text-red"></i>
                    </td>
                </tr>
                <tr>
                    <td>Proveedor B</td>
                    <td>Madera</td>
                    <td>$80.00 MXN</td>
                    <td>
                        <i class="fas fa-pen text-yellow"></i>
                        <i class="fas fa-times text-red"></i>
                    </td>
                </tr>
                <tr>
                    <td>Proveedor C</td>
                    <td>Cemento</td>
                    <td>$60.00 MXN</td>
                    <td>
                        <i class="fas fa-pen text-yellow"></i>
                        <i class="fas fa-times text-red"></i>
                    </td>
                </tr>
            </tbody>
        </table>

        <p class="reporte">¿Tienes problemas? <a href="#">Generar reporte</a></p>
    </div>
</body>
</html>
