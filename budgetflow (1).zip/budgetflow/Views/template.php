<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BudgetFlow - Gestión Financiera</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <?php
    // Mensajes de alerta globales (fuera del contenedor principal)
    if (isset($_SESSION['global_success'])) {
        echo '<div class="global-message success">' . $_SESSION['global_success'] . '</div>';
        unset($_SESSION['global_success']);
        
        // Script para ocultar el mensaje después de unos segundos
        echo '<script>
            setTimeout(function() {
                var message = document.querySelector(".global-message");
                if (message) message.style.display = "none";
            }, 5000);
        </script>';
    }
    
    if (isset($_SESSION['global_error'])) {
        echo '<div class="global-message error">' . $_SESSION['global_error'] . '</div>';
        unset($_SESSION['global_error']);
        
        // Script para ocultar el mensaje después de unos segundos
        echo '<script>
            setTimeout(function() {
                var message = document.querySelector(".global-message");
                if (message) message.style.display = "none";
            }, 5000);
        </script>';
    }
    
    // Contenedor principal que tendrá el contenido
    echo '<div class="main-container">';
    
    // Aquí se incluirán las diferentes vistas desde el controlador
    
    echo '</div>'; // Fin del main-container
    ?>
</body>
</html>