<div class="success-container">
    <h2 class="success-title">cotización con éxito</h2>
    
    <p class="success-message">Su cotización se ha enviado con éxito</p>
    
    <div class="success-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
            <polyline points="22 4 12 14.01 9 11.01"></polyline>
        </svg>
    </div>
    
    <div class="success-actions">
        <a href="index.php?action=dashboard_cliente" class="btn-link">Volver al menú de opciones</a>
    </div>
</div>