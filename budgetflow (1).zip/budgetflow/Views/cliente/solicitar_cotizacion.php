<div class="dashboard-header">
    <div class="back-button">
        <a href="index.php?action=dashboard_cliente">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Atrás
        </a>
    </div>
    <h1 class="page-title">Solicitar cotización</h1>
</div>

<div class="form-container">
    <h2 class="form-title">Detalles de la cotización</h2>
    
    <form action="index.php?action=cliente_procesar_cotizacion" method="POST" class="quote-form">
        <div class="form-group">
            <label for="id_empresa">ID de empresa</label>
            <input type="text" id="id_empresa" name="id_empresa" placeholder="Ingrese el id" required>
        </div>
        
        <div class="form-group">
            <label for="material">Material</label>
            <input type="text" id="material" name="material" placeholder="Ingrese el material" required>
        </div>
        
        <div class="form-group">
            <label for="dimensiones">Dimensiones (m²)</label>
            <input type="text" id="dimensiones" name="dimensiones" placeholder="Ej: 100 m²" required>
        </div>
        
        <div class="form-group">
            <label for="cantidad">Cantidad</label>
            <input type="number" id="cantidad" name="cantidad" placeholder="Ej: 5 unidades" required>
        </div>
        
        <div class="form-group">
            <label for="fecha">Fecha de solicitud</label>
            <input type="date" id="fecha" name="fecha" required>
        </div>
        
        <div class="form-actions">
            <button type="button" class="btn-secondary" onclick="window.location.href='index.php?action=dashboard_cliente'">Cancelar</button>
            <button type="submit" class="btn-primary">Confirmar</button>
        </div>
    </form>
</div>