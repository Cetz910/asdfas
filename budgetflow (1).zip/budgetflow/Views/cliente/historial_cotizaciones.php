<div class="dashboard-header">
    <div class="back-button">
        <a href="index.php?action=dashboard_cliente">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Atrás
        </a>
    </div>
    <h1 class="page-title">Historial de Cotización</h1>
    
    <div class="filter-container">
        <input type="text" id="filterInput" placeholder="Filtrar por: Nombre" class="filter-input">
    </div>
</div>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<div class="table-container">
    <?php if (empty($cotizaciones)): ?>
        <div class="empty-state">
            <p>No tienes cotizaciones registradas aún.</p>
            <a href="index.php?action=cliente_solicitar_cotizacion" class="btn-primary">Solicitar Cotización</a>
        </div>
    <?php else: ?>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Pedido</th>
                    <th>Material</th>
                    <th>Dimensiones</th>
                    <th>Cantidad</th>
                    <th>Fecha</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($cotizaciones as $cotizacion): 
                    $estadoClass = '';
                    switch ($cotizacion['estado']) {
                        case 'Completado':
                            $estadoClass = 'status-completed';
                            break;
                        case 'Progreso':
                            $estadoClass = 'status-progress';
                            break;
                        case 'Pendiente':
                            $estadoClass = 'status-pending';
                            break;
                        case 'Cancelado':
                            $estadoClass = 'status-canceled';
                            break;
                    }
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($cotizacion['id_empresa']); ?></td>
                    <td><?php echo htmlspecialchars($cotizacion['material']); ?></td>
                    <td><?php echo htmlspecialchars($cotizacion['dimensiones']); ?></td>
                    <td><?php echo htmlspecialchars($cotizacion['cantidad']); ?></td>
                    <td><?php echo date('d/m/Y', strtotime($cotizacion['fecha_solicitud'])); ?></td>
                    <td><span class="status <?php echo $estadoClass; ?>"><?php echo htmlspecialchars($cotizacion['estado']); ?></span></td>
                    <td class="actions-cell">
                        <!-- Solo se muestra eliminar, no editar -->
                        <form action="index.php?action=cliente_eliminar_cotizacion" method="POST" style="display:inline;">
                            <input type="hidden" name="id_cotizacion" value="<?php echo $cotizacion['id']; ?>">
                            <button type="submit" class="btn-delete" onclick="return confirm('¿Estás seguro de que deseas eliminar esta cotización?')">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<div class="support-container">
    <p>¿Tienes problemas? <a href="index.php?action=cliente_generar_reporte" class="support-link">Generar reporte</a></p>
</div>

<script>
// JavaScript para el filtrado de la tabla
document.getElementById('filterInput').addEventListener('keyup', function() {
    const filterValue = this.value.toLowerCase();
    const tableRows = document.querySelectorAll('.data-table tbody tr');
    
    tableRows.forEach(row => {
        const text = row.textContent.toLowerCase();
        if (text.includes(filterValue)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});
</script>