<div class="dashboard-header">
    <div class="back-button">
        <a href="index.php?action=dashboard_cliente">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Atrás
        </a>
    </div>
    <h1 class="page-title">Generar Reporte</h1>
</div>

<div class="form-container">
    <h2 class="form-title">¿Qué problema estás experimentando?</h2>
    
    <form action="index.php?action=cliente_enviar_reporte" method="POST" class="report-form">
        <div class="form-group">
            <label for="tipo_problema">Tipo de problema</label>
            <select id="tipo_problema" name="tipo_problema" required>
                <option value="">Selecciona un tipo de problema</option>
                <option value="tecnico">Problema técnico</option>
                <option value="facturacion">Problema de facturación</option>
                <option value="cotizacion">Problema con cotización</option>
                <option value="otro">Otro</option>
            </select>
        </div>
        
        <div class="form-group">
            <label for="descripcion">Descripción del problema</label>
            <textarea id="descripcion" name="descripcion" rows="5" placeholder="Describe detalladamente el problema que estás experimentando" required></textarea>
        </div>
        
        <div class="form-group">
            <label for="email_contacto">Email de contacto</label>
            <input type="email" id="email_contacto" name="email_contacto" value="<?php echo isset($_SESSION['usuario_email']) ? $_SESSION['usuario_email'] : ''; ?>" required>
        </div>
        
        <div class="form-actions">
            <button type="button" class="btn-secondary" onclick="window.location.href='index.php?action=dashboard_cliente'">Cancelar</button>
            <button type="submit" class="btn-primary">Enviar Reporte</button>
        </div>
    </form>
</div>