<?php
// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'budgetflow');
define('DB_USER', 'root');
define('DB_PASS', '');

// Configuración de la aplicación
define('BASE_URL', 'http://localhost/budgetflow/');
define('APP_NAME', 'BudgetFlow');

// Configuración del correo (para recuperación de contraseña)
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'tu_correo@gmail.com');
define('MAIL_PASSWORD', 'tu_password_app');
define('MAIL_FROM', 'noreply@budgetflow.com');
define('MAIL_NAME', 'BudgetFlow');
?>